# SOL-NEET Stop Loss Bot

Monitors NEET token price and executes stop loss when threshold is reached.

## Setup
1. `npm install`
2. Add your wallet private key to `.env`
3. Update token addresses in `index.js`
4. `npm start`
